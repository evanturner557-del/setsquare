# CIS Deduction Tracker — what's in this download

Thank you for buying the CIS Deduction Tracker (£12 digital download).

## Files in this zip
1. **CIS-Deduction-Tracker.xlsx** — blank CIS payment and deduction log for UK subcontractors (Excel; most buyers can also upload it to Google Sheets).
2. **CIS-Deduction-Tracker-Worked-Example.xlsx** — the same tracker filled with example data so you can see how it works.
3. **CIS-Tracker-Quick-Start.pdf** — one-page plain-English quick start.

## How to open
- **.xlsx** — Microsoft Excel, LibreOffice Calc, or upload to Google Sheets (File → Import).
- **.pdf** — any PDF reader (Preview, Adobe Reader, browser). Print A4 if you want a paper copy.

## Important limits (please read)
- This is a **record-keeping aid**, not HMRC-recognised software. It cannot send anything to HMRC.
- This is **not tax, legal or financial advice**. Check GOV.UK or an accountant for your own situation.
- Pack wording is **Draft / UNVERIFIED** where labelled in the source files. Treat rates and dates as labelled; re-check before you rely on them.

## No fake promises
There is no guarantee of tax savings, HMRC acceptance, or specific results. If a file will not open or looks corrupt, contact the seller through the marketplace message thread with your order details.

## Status of this pack
Local product build from the E4 CIS tracker (`engine/experiments/e4-cis-tracker/dist/`). Instant digital download only — nothing physical is posted. This README does not create a checkout or activate refund terms. Sold as its own £12 listing (not a Setsquare bundle) until first sale.
