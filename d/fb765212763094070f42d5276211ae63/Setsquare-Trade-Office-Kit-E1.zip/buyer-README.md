# Setsquare Trade Office Kit — what's in this download

Thank you for buying the Setsquare Trade Office Kit (£19 digital download).

## Files in this zip
1. **Setsquare-Office-Procedures.docx** — 12 editable office procedures (enquiries through month-end) for UK heating and plumbing firms (and similar trades). Open the .docx in Word or Google Docs (or LibreOffice Writer).
2. **Setsquare-Office-Procedures.odt** — the same procedures in OpenDocument format.
3. **Setsquare-Office-Procedures.pdf** — the same procedures as a printable PDF.
4. **Setsquare-Office-Checklists.pdf** — 12 one-page printable checklists matching the procedures (print, pin up, tick off).
5. **Setsquare-MTD-Record-Tracker.xlsx** — bonus Making Tax Digital income/expense/mileage tracker with formulas, for **sole-trader owners** (MTD for Income Tax does not cover limited companies). Built and tested in LibreOffice Calc only.
6. **Setsquare-MTD-Worked-Example.xlsx** — bonus: the same tracker filled with an example trader so you can see how it works (LibreOffice Calc tested).
7. **Setsquare-MTD-Guide.pdf** — short plain-English guide on what MTD means for a UK sole trader and how to use the tracker.
8. **Setsquare-Free-Quarterly-Checklist.pdf** — one-page quarter tick-list.
9. **buyer-README.md** — this file.

## How to open
- **.docx** — open the .docx in Word or Google Docs (File → Open / upload). Also opens in LibreOffice Writer. There is no separate native Google Docs file.
- **.odt** — LibreOffice Writer, or upload to a word processor that accepts OpenDocument.
- **.xlsx** — open in LibreOffice Calc (formulas built and tested there: 213 automated checks). Setsquare has not tested Microsoft Excel or Google Sheets and does not claim they work.
- **.pdf** — any PDF reader (Preview, Adobe Reader, browser). Print A4 if you want paper copies.

## Important limits (please read)
- The procedures and checklists are **office and admin only**. They are not health and safety, gas, electrical, legal or HR advice.
- The MTD tracker is a **record-keeping kit**, not HMRC-recognised software. It cannot send anything to HMRC. You still need HMRC-recognised (or bridging) software to submit quarterly updates.
- MTD for Income Tax applies to sole traders and landlords, not limited companies.
- This is **not tax, legal or financial advice**. Check GOV.UK or an accountant for your own situation.
- Re-check rates and dates on GOV.UK before you rely on them; they change.

## Contact
Operated by a UK sole trader trading as Setsquare. Contact: localreply+setsquare@agentmail.to (receive-only; no reply is promised). If a file will not open or looks corrupt, use the marketplace message thread with your order details where the platform provides one.

## No fake promises
There is no guarantee of tax savings, HMRC acceptance, or specific results.

## Status of this pack
Local product build from the E1 Setsquare kit (`engine/experiments/e1-setsquare-kit/dist/`) plus steps-v1 office procedures. Instant digital download only — nothing physical is posted. This README does not create a checkout or activate refund terms.
